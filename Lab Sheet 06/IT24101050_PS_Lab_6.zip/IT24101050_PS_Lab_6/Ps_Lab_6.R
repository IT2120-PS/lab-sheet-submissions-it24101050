setwd("/Users/forgetmenotblue/Desktop/IT24101050_PS_Lab_6")
#1.
# I. The random variable x has a distribution of p = 0.85 and n = 50

# II. 
1 - pbinom(46, 50, 0.85)

#2.
# I. The number of calls per day

# II. The random variable x has a poissom distribution of lambda = 12

# III
dpois(15, 12)


