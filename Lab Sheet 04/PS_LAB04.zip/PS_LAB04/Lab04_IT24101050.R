# Exercise 1

setwd("C:/users/it24101050/Desktop/PS_LAB03")
branch_data <- read.csv("C:Users/it24101050/Documents/DATA 4.txt", header = TRUE, sep = " ")

# Exercise 2
str(branch_data)
scale(branch_data)

# Exercise 3
boxplot(branch_data$Sales_X1, main = "Sales Distribution")
# It is approximately a symmetric skew however it shows a mild left skew.

# Exercise 4
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

# Exercise 5
get.outliers<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound =", ub))
  print(paste("Lower Bound =", lb))
  print(paste("Outliers:", sort(z[z < lb | z > ub]), collapse = " , "))
}

get.outliers(branch_data$Years_X3)