setwd("/Users/forgetmenotblue/Downloads")

data <- read.table("Exercise - LaptopsWeights.txt",header = TRUE)
fix(data)
attach(data)

#Question1

popmn<-mean(Weight.kg.)

popsd<-sd(Weight.kg.)

print(paste("Population mean =", popmn))
print(paste("Population SD =", popsd))



#Question 02
samples<-c()
n<-c()

for(i in 1:25){
  s<-sample(Weight.kg.,6,replace=TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('S',i))
}

colnames(samples)=n

s.means<-apply(samples,2,mean)
s.sds<-apply(samples,2,sd)


print("Sample means:")
print(s.means)

print("Sample standard deviations:")
print(s.sds)


#Question 03
mean.samplemeans<-mean(s.means)
sd.samplemeans<-sd(s.means)

print(paste("Mean of 25 ssample means =",mean.samplemeans))
print(paste("Standard deviation of 25 sample means =", sd.samplemeans))

print(paste("True mean =", popmn))
print(paste("True SD =", popsd/sqrt(6)))

